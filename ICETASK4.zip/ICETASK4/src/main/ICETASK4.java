/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package icetask4;
import java.util.Scanner;
/**15
 *2
 * @author Hp-PC
 */
public class ICETASK4 {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        // Ask for the number of salespeople
        System.out.print("Enter the number of salespeople: ");
        int numSalespeople = scan.nextInt();

        int[] sales = new int[numSalespeople];

        // Reads sales amounts and calculate sum, max, and min
        int sum = readSales(scan, sales);
        
        // Calculates the average sale
        double average = (double) sum / numSalespeople;
        
        // Finds the maximum and minimum sales
        int maxSale = Integer.MIN_VALUE;
        int minSale = Integer.MAX_VALUE;
        int maxId = -1;
        int minId = -1;
        
        for (int i = 0; i < sales.length; i++) {
            if (sales[i] > maxSale) {
                maxSale = sales[i];
                maxId = i + 1;  // Adjusts ID to start from 1
            }
            if (sales[i] < minSale) {
                minSale = sales[i];
                minId = i + 1;  // Adjusts ID to start from 1
            }
        }

        // Prints the results
        printSales(sales);
        printSummary(sum, average, maxSale, minSale, maxId, minId);

        // Compares sales against user-specified value
        compareSales(scan, sales);
    }

    private static int readSales(Scanner scan, int[] sales) {
        int sum = 0;
        for (int i = 0; i < sales.length; i++) {
            System.out.print("Enter sales for sales person " + (i + 1) + ": ");
            sales[i] = scan.nextInt();
            sum += sales[i];
        }
        return sum;
    }

    private static void printSales(int[] sales) {
        System.out.println("\nSales person Sales");
        System.out.println("--------------------");
        for (int i = 0; i < sales.length; i++) {
            System.out.println(" " + (i + 1) + " " + sales[i]);
        }
    }

    private static void printSummary(int sum, double average, int maxSale, int minSale, int maxID, int minID) {
        System.out.println("\nTotal sales: " + sum);
        System.out.println("Average sale: " + average);
        System.out.println("Sales person " + maxID + " had the highest sale with $" + maxSale);
        System.out.println("Sales person " + minID + " had the lowest sale with $" + minSale);
    }

    private static void compareSales(Scanner scan, int[] sales) {
        System.out.print("\nEnter a value to compare sales: ");
        int value = scan.nextInt();
        int count = 0;

        System.out.println("Salespeople who exceeded $" + value + ":");
        for (int i = 0; i < sales.length; i++) {
            if (sales[i] > value) {
                System.out.println("Salesperson " + (i + 1) + " with sales $" + sales[i]);
                count++;
            }
        }
        System.out.println("Total number of salespeople who exceeded the amount: " + count);
    }
}
