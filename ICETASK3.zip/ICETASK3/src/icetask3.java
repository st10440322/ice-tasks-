
public class icetask3 {

    public static void main(String[] args) {
        int limit = 20;
        int sum = oddSquaresSum(limit);
        System.out.println("Sum of Squares of odd numbers up to " + limit + ": " + sum);

        int num1 = 10;
        int num2 = 15;
        int output = greatestCommonDivisor(num1, num2);
        System.out.println("Greatest Common Divisor of " + num1 + " and " + num2 + " is: " + output);

        System.out.println(Parentheses("{}{)}") + " {}{)} is invalid");
        System.out.println(Parentheses("{[}]") + " {[}] is invalid");
        System.out.println(Parentheses("()") + " () is valid");
        System.out.println(Parentheses("({[]})") + " ({[]}) is valid");
        System.out.println(Parentheses("") + " Empty parentheses is invalid");
    }

    // Question 2: odd_squares_sum generator function
    public static int oddSquaresSum(int limit) {
        int sum = 0;
        for (int i = 1; i <= limit; i += 2) {
            sum += i * i;
        }
        return sum;
    }

    // Question 3: greatest_common_divisor function
    public static int greatestCommonDivisor(int a, int b) {
        int gcd = 1;
        for (int i = 1; i <= Math.min(a, b); i++) {
            if (a % i == 0 && b % i == 0) {
                gcd = i;
            }
        }
        return gcd;
    }

    // Function to validate parentheses
    public static String Parentheses(String n) {
        if (n.isEmpty()) {
            return "invalid"; // Empty string is invalid
        }

        boolean isOpen = false;
        int balance = 0;

        for (char R : n.toCharArray()) {
            if (R == '(' || R == '{' || R == '[') {
                isOpen = true;
                balance++;
            } else if ((R == ')' || R == '}' || R == ']') && isOpen) {
                balance--;
            } else {
                return "invalid";
            }
        }

        return (balance == 0 && isOpen) ? "valid" : "invalid";
    }
}
